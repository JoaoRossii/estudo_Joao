package br.com.alura.bytebank.domain.cliente;

import java.time.LocalDate;

public record DadosCadastroCliente(String nome, String cpf, String email) {
}
